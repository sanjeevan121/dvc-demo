from setuptools import setup,find_packages

setup(name='src',
    version='0.0.1',
    description='mlops package',
    author='sanjeevan thorat',packages=find_packages(),author_email='sanjeevan.k.thorat@gmail.com',license="MIT")